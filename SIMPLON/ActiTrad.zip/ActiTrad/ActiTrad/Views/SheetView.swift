//
//  SheetView.swift
//  ActiTrad
//
//  Created by Apprenant 172 on 06/06/2024.
//

import SwiftUI

struct SheetView: View {
    var body: some View {
        Text("Merci de compléter modal ici")
    }
}

#Preview {
    SheetView()
}
